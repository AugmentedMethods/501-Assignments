/**
 * Created with IntelliJ IDEA.
 * User: Sean
 * Date: 11/11/13
 * Time: 1:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class ObjectCreator {
}
