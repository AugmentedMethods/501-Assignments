package BasicObjects;

/**
 * Created with IntelliJ IDEA.
 * User: Sean
 * Date: 11/11/13
 * Time: 1:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConnectedObjects {
    private SimpleObjectWithPrimitives secondObj;

    public ConnectedObjects(SimpleObjectWithPrimitives obj)
    {
        secondObj = obj;
    }

}
