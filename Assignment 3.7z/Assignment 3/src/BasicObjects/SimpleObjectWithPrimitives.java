package BasicObjects;

/**
 * Created with IntelliJ IDEA.
 * User: Sean
 * Date: 11/11/13
 * Time: 1:43 PM
 * To change this template use File | Settings | File Templates.
 */

public class SimpleObjectWithPrimitives {
    private int var1;
    public double var2;

    public SimpleObjectWithPrimitives(int var1, int var2)
    {
        this.var1 = var1;
        this.var2 = var2;
    }



}
