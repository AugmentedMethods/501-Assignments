/**
 * Created with IntelliJ IDEA.
 * User: Sean
 * Date: 10/20/13
 * Time: 9:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class InterfaceDetails {
}
