public interface InterfaceA extends InterfaceB
{
   
    public void func1(int a,double b,boolean c, String s) throws Exception;
    public int func2(String s)throws Exception, ArithmeticException , IllegalMonitorStateException ;

}
